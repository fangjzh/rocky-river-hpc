#!/bin/sh

source ./env.sh
. /etc/profile.d/xcat.sh
##
echo "boot and wait the compute node install before stage 05!"